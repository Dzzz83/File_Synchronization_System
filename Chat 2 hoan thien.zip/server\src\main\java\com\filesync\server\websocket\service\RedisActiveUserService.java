package com.filesync.server.websocket.service;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Set;
import java.util.UUID;

@Service
public class RedisActiveUserService implements ActiveUserService {

    private static final String REDIS_PREFIX = "folder:active:";
    private final StringRedisTemplate redisTemplate;

    public RedisActiveUserService(StringRedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    private String getRedisKey(UUID folderId) {
        return REDIS_PREFIX + folderId.toString();
    }

    @Override
    public void userJoined(UUID folderId, String username) {
        String key = getRedisKey(folderId);
        redisTemplate.opsForSet().add(key, username);
    }

    @Override
    public void userLeft(UUID folderId, String username) {
        String key = getRedisKey(folderId);
        redisTemplate.opsForSet().remove(key, username);
    }

    @Override
    public Set<String> getActiveUsers(UUID folderId) {
        String key = getRedisKey(folderId);
        Set<String> members = redisTemplate.opsForSet().members(key);
        return members != null ? members : Collections.emptySet();
    }
}
