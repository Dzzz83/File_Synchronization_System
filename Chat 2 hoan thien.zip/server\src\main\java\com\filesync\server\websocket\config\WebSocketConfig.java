package com.filesync.server.websocket.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

import java.net.URI;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    @Value("${CLOUDAMQP_URL:amqp://guest:guest@localhost:5672}")
    private String cloudAmqpUrl;

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        String host = "localhost";
        int port = 61613;
        String username = "guest";
        String passcode = "guest";
        String virtualHost = "/";

        try {
            if (cloudAmqpUrl != null && (cloudAmqpUrl.startsWith("amqp://") || cloudAmqpUrl.startsWith("amqps://"))) {
                // URI class requires "amqp" or "amqps" scheme, which matches
                URI uri = new URI(cloudAmqpUrl);
                host = uri.getHost();
                
                String userInfo = uri.getUserInfo();
                if (userInfo != null && userInfo.contains(":")) {
                    String[] parts = userInfo.split(":", 2);
                    username = parts[0];
                    passcode = parts[1];
                }
                
                if (uri.getPath() != null && uri.getPath().length() > 1) {
                    virtualHost = uri.getPath().substring(1);
                }
                
                System.out.println("Parsed CloudAMQP STOMP configuration - Host: " + host + ", VHost: " + virtualHost);
            }
        } catch (Exception e) {
            System.err.println("Error parsing CLOUDAMQP_URL for STOMP relay config, falling back to defaults: " + e.getMessage());
        }

        config.enableStompBrokerRelay("/topic", "/queue")
                .setRelayHost(host)
                .setRelayPort(port)
                .setSystemLogin(username)
                .setSystemPasscode(passcode)
                .setClientLogin(username)
                .setClientPasscode(passcode)
                .setVirtualHost(virtualHost);

        config.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws/chat")
                .setAllowedOriginPatterns("*")
                .withSockJS();
    }
}
