package com.filesync.client.websocket;

import com.filesync.common.dto.ChatMessage;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.*;
import org.springframework.web.socket.WebSocketHttpHeaders;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

import java.lang.reflect.Type;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

public class ChatClient {
    private WebSocketStompClient stompClient;
    private StompSession session;
    private final String baseUrl;
    private final String authToken;

    public ChatClient(String baseUrl, String authToken) {
        this.baseUrl = baseUrl;
        this.authToken = authToken;
    }

    public void connect(UUID folderId, Consumer<ChatMessage> onMessage, Consumer<Set> onActiveUsersUpdate) {
        StandardWebSocketClient webSocketClient = new StandardWebSocketClient();
        stompClient = new WebSocketStompClient(webSocketClient);
        stompClient.setMessageConverter(new MappingJackson2MessageConverter());

        String wsTemp = baseUrl.replace("http://", "ws://").replace("https://", "wss://");
        final String wsUrl = wsTemp.endsWith("/") ? wsTemp + "ws/chat/websocket" : wsTemp + "/ws/chat/websocket";

        StompSessionHandler sessionHandler = new StompSessionHandlerAdapter() {
            @Override
            public void afterConnected(StompSession stompSession, StompHeaders connectedHeaders) {
                session = stompSession;
                System.out.println("Connected to STOMP WebSocket server at " + wsUrl);

                // Subscribe to chat messages for the folder
                session.subscribe("/topic/folder/" + folderId.toString(), new StompFrameHandler() {
                    @Override
                    public Type getPayloadType(StompHeaders headers) {
                        return ChatMessage.class;
                    }

                    @Override
                    public void handleFrame(StompHeaders headers, Object payload) {
                        if (payload instanceof ChatMessage) {
                            onMessage.accept((ChatMessage) payload);
                        }
                    }
                });

                // Subscribe to active users list updates for the folder
                session.subscribe("/topic/folder/" + folderId.toString() + "/active", new StompFrameHandler() {
                    @Override
                    public Type getPayloadType(StompHeaders headers) {
                        return Set.class;
                    }

                    @Override
                    public void handleFrame(StompHeaders headers, Object payload) {
                        if (payload instanceof Set) {
                            onActiveUsersUpdate.accept((Set) payload);
                        }
                    }
                });
            }

            @Override
            public void handleException(StompSession session, StompCommand command, StompHeaders headers, byte[] payload, Throwable exception) {
                System.err.println("STOMP Client Exception: " + exception.getMessage());
                exception.printStackTrace();
            }

            @Override
            public void handleTransportError(StompSession session, Throwable exception) {
                System.err.println("STOMP Transport Error: " + exception.getMessage());
            }
        };

        // Pass authentication token via STOMP headers
        StompHeaders connectHeaders = new StompHeaders();
        if (authToken != null && !authToken.isEmpty()) {
            connectHeaders.add("Authorization", "Bearer " + authToken);
        }

        // Use explicit 4-arg overload (WebSocketHttpHeaders, StompHeaders) to resolve ambiguity
        WebSocketHttpHeaders httpHeaders = new WebSocketHttpHeaders();
        if (authToken != null && !authToken.isEmpty()) {
            httpHeaders.add("Authorization", "Bearer " + authToken);
        }
        stompClient.connectAsync(wsUrl, httpHeaders, connectHeaders, sessionHandler);
    }

    public void sendMessage(ChatMessage message) {
        if (session != null && session.isConnected()) {
            session.send("/app/chat.send", message);
        } else {
            System.err.println("Cannot send message: STOMP session is not connected.");
        }
    }

    public void disconnect() {
        try {
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
            if (stompClient != null && stompClient.isRunning()) {
                stompClient.stop();
            }
            System.out.println("Disconnected STOMP WebSocket client");
        } catch (Exception e) {
            System.err.println("Error during STOMP disconnect: " + e.getMessage());
        }
    }
}
