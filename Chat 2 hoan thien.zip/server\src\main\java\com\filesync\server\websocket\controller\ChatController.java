package com.filesync.server.websocket.controller;

import com.filesync.common.dto.ChatMessage;
import com.filesync.server.websocket.service.ActiveUserService;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;
import org.springframework.web.socket.messaging.SessionSubscribeEvent;

import java.security.Principal;
import java.time.Instant;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Controller
public class ChatController {

    private final ActiveUserService activeUserService;
    private final SimpMessagingTemplate messagingTemplate;
    
    // Map to keep track of folder subscriptions per session: sessionId -> Set of folderIds
    private final Map<String, Set<UUID>> sessionSubscriptions = new ConcurrentHashMap<>();

    public ChatController(ActiveUserService activeUserService, SimpMessagingTemplate messagingTemplate) {
        this.activeUserService = activeUserService;
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/chat.send")
    public void sendMessage(ChatMessage message) {
        message.setTimestamp(Instant.now());
        messagingTemplate.convertAndSend("/topic/folder/" + message.getFolderId().toString(), message);
    }

    @EventListener
    public void handleSessionSubscribe(SessionSubscribeEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        String destination = accessor.getDestination();
        
        if (destination != null && destination.startsWith("/topic/folder/")) {
            // Destinations look like:
            // 1. /topic/folder/{folderId}
            // 2. /topic/folder/{folderId}/active
            // We parse the folderId component (which is the third element after splitting by "/")
            String[] parts = destination.split("/");
            if (parts.length >= 4) {
                try {
                    UUID folderId = UUID.fromString(parts[3]);
                    Principal principal = accessor.getUser();
                    String username = principal != null ? principal.getName() : null;
                    String sessionId = accessor.getSessionId();
                    
                    if (username != null && sessionId != null) {
                        // Track the subscription for cleanup when this session disconnects
                        sessionSubscriptions.computeIfAbsent(sessionId, k -> ConcurrentHashMap.newKeySet()).add(folderId);
                        
                        // Add the user to the active list for this folder
                        activeUserService.userJoined(folderId, username);
                        
                        // Broadcast the updated list of active users in this folder
                        messagingTemplate.convertAndSend("/topic/folder/" + folderId.toString() + "/active", activeUserService.getActiveUsers(folderId));
                        System.out.println("User " + username + " subscribed/joined folder: " + folderId);
                    }
                } catch (IllegalArgumentException e) {
                    System.err.println("Invalid UUID in subscription destination: " + destination);
                }
            }
        }
    }

    @EventListener
    public void handleSessionDisconnect(SessionDisconnectEvent event) {
        String sessionId = event.getSessionId();
        Principal principal = event.getUser();
        
        if (sessionId != null && principal != null) {
            String username = principal.getName();
            Set<UUID> folderIds = sessionSubscriptions.remove(sessionId);
            
            if (folderIds != null) {
                for (UUID folderId : folderIds) {
                    activeUserService.userLeft(folderId, username);
                    // Broadcast updated list to remaining users
                    messagingTemplate.convertAndSend("/topic/folder/" + folderId.toString() + "/active", activeUserService.getActiveUsers(folderId));
                    System.out.println("User " + username + " disconnected/left folder: " + folderId);
                }
            }
        }
    }
}
